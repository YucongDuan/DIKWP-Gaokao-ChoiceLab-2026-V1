#!/usr/bin/env python3
"""Offline rank-band helper for DIKWP Gaokao ChoiceLab 2026 V1.
No admission guarantee; official verification required.
"""
from __future__ import annotations
import argparse,csv,json,statistics
from pathlib import Path

def band(row,rank):
    rs=[int(float(row[k])) for k in ('rank_2023','rank_2024','rank_2025') if row.get(k)]
    if not rs:return 'new_or_insufficient'
    med=statistics.median(rs);success=sum(rank<=r for r in rs)/len(rs);gap=(med-rank)/med;vol=(max(rs)-min(rs))/med
    if success==1 and gap>=.08 and vol<.28:return 'safe_history_band'
    if success>=.67 and gap>=-.01:return 'target_history_band'
    if success>=.33 or gap>=-.10:return 'reach_history_band'
    return 'high_risk_history_band'

def main():
    p=argparse.ArgumentParser();p.add_argument('csv',type=Path);p.add_argument('--rank',type=int,required=True);p.add_argument('--out',type=Path,default=Path('gaokao_rank_bands.json'));a=p.parse_args()
    rows=list(csv.DictReader(a.csv.open(encoding='utf-8-sig')))
    out=[]
    for r in rows:
        r['history_band']=band(r,a.rank);out.append(r)
    payload={'rank':a.rank,'official_verification_required':True,'admission_guarantee':False,'options':out}
    a.out.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    print(a.out)
if __name__=='__main__':main()
