# Official Research Sources (checked June 2026)

- Ministry of Education, Notice on 2026 Regular Higher-Education Admissions.
- Sunshine Gaokao, 2026 Volunteer-Application Guide, admissions charters, institution and major information.
- Ministry of Education, List of Higher-Education Institutions (2026): 3,196 institutions, including 1,412 undergraduate institutions and 1,540 higher-vocational colleges.
- Ministry of Education, Undergraduate Major Catalogue (2026): 13 disciplines, 92 major categories, 883 majors; four new majors include Embodied Intelligence, Brain-Computer Science and Technology, Engineering Internet, and Deep-Earth Science and Engineering.
- State Council, Opinion on Deeply Implementing the “AI+” Action (2025).
- Fifteenth Five-Year Plan Outline (2026) and 2026 Government Work Report.
- Provincial examination-authority 2026 application instructions, including Guangdong, Jiangsu, Zhejiang, Shandong, Hebei, Liaoning, Fujian and Sichuan examples.
- Ministry of Education / China Disabled Persons’ Federation, Guidance on Physical Examination for Regular Higher-Education Admissions.

All official rules and data must be rechecked for the candidate’s province, batch, subject combination, and institution before submission.
