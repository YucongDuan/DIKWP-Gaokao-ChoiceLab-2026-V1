#!/usr/bin/env python3
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parent
patterns=[r'\brequests\.',r'\burllib\.request',r'\bsocket\.',r'\beval\(',r'\bexec\(',r'\bos\.system']
findings=[]
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.html','.js','.py'} and p.name!='static_boundary_audit.py':
        t=p.read_text(encoding='utf-8',errors='ignore')
        for q in patterns:
            if re.search(q,t):findings.append({'file':str(p.relative_to(ROOT)),'pattern':q})
report={'network_or_dynamic_execution_detected':bool(findings),'findings':findings,'note':'No official application-system submission, credential storage, or remote data collection is included.'}
(ROOT/'static_boundary_audit_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
