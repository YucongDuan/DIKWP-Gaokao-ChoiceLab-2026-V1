# 72-Hour Gaokao Volunteer Workflow

## Hour 0–6: Freeze official data
- download the 2026 provincial plan, one-point-one-rank table, and application rules
- record candidate rank, subject combination, physical-exam conclusion and hard budget
- do not begin with school rankings or social-media lists

## Hour 6–18: Build the candidate pool
- apply hard subject/physical/language/single-subject filters
- use program-level or professional-group-level historical ranks matching the province’s mode
- create a broad pool of 80–150 options where applicable

## Hour 18–36: Understand majors and institutions
- inspect curriculum, faculty, laboratories, campus, tuition, major diversion and transfer rules
- classify AI exposure, complementarity, domain barrier and postgraduate dependency
- identify 3–5 shared family priorities and red lines

## Hour 36–54: Construct the list
- build reach / target / safe bands
- ensure safe options are genuinely acceptable
- inspect every professional group for adjustment red lines
- order by genuine preference within the provincial filing rule

## Hour 54–66: Verify charters
- check admission rules, adjustment, withdrawal conditions, physical examination, language, single-subject requirements, campus, tuition and major diversion
- call admissions offices for unresolved high-impact questions

## Hour 66–72: Final review and submission
- recheck provincial corrections and supplements
- export/print the final list
- student and parent jointly read and confirm
- submit only through the official provincial system
