# Governance and Safety Boundary

## Authoritative-source order
1. 2026 provincial examination authority admission plan and one-point-one-rank table.
2. 2026 university admissions charter and official admissions site.
3. Provincial examination authority / university official historical program ranks.
4. Official curriculum, discipline, employment-quality, tuition and financial-aid information.
5. Third-party platforms only as leads; never as final authority.

## Prohibited claims
- guaranteed admission
- exact admission probability
- guaranteed employment, salary, civil-service or postgraduate outcome
- a major is “safe from AI” or “certain to disappear”
- a new major is automatically better
- school ranking alone determines individual outcome

## Kill conditions
Stop final-list generation if:
- official 2026 plan or charter has not been verified
- subject, physical, language, single-subject or special qualification fails
- professional group contains an unacceptable major and adjustment is required
- there are no genuinely acceptable safe options
- family cost exceeds the hard budget boundary
- student and parent conflict remains unresolved
- imported data sources conflict and cannot be reconciled

## Privacy
Do not upload identity card numbers, exam passwords, face data, health records, home addresses or other unnecessary personal information. The prototype processes local browser data only.
